-- MySQL dump 10.13  Distrib 8.0.18, for Win64 (x86_64)
--
-- Host: localhost    Database: műsorújság
-- ------------------------------------------------------
-- Server version	8.0.18

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `vélemény`
--

DROP TABLE IF EXISTS `vélemény`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `vélemény` (
  `vélemény_kód` int(11) NOT NULL AUTO_INCREMENT,
  `véleményezett_műsor_címe` varchar(50) NOT NULL,
  `vélemény` longtext,
  PRIMARY KEY (`vélemény_kód`),
  KEY `rendezett_műsor_címe_idx` (`véleményezett_műsor_címe`),
  CONSTRAINT `véleményezett_műsor_címe` FOREIGN KEY (`véleményezett_műsor_címe`) REFERENCES `műsor` (`címe`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=246 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vélemény`
--

LOCK TABLES `vélemény` WRITE;
/*!40000 ALTER TABLE `vélemény` DISABLE KEYS */;
INSERT INTO `vélemény` VALUES (211,'27 idegen igen','Mindig meg kell néznem, kategóriájában 10-es !'),(212,'27 idegen igen','Ez nagyon aranyos film volt!'),(213,'A bűn királynői','Teljesen jó film, Nagyon élveztük 10/10. '),(214,'A csendestárs','Kedvenc filmeim egyike.'),(215,'A csendestárs','Fergeteges!! Imádtam minden percét :'),(216,'A kém','Nagyon nagyon jó film, nem tudom eddig miért kerülte el a figyelmem! 10 pont :-) '),(217,'A kém',' Kedves film. Úgy nevettet, hogy jókedvre derít. És nem a hasamat csiklandozza. Meccsoda különbség! '),(218,'A királynő','Még én sem láttam, így most igazán kellemes meglepetés volt.'),(219,'A királynő','Nagyon jó kis film:) Többször nézhető.'),(220,'A királynő','Én ma láttam elõször a filmet, nekem nagyon tetszett.'),(221,'A múmia','A Múmia filmek közül ez az egyetlen nézhető kategória, a többi felejtős. '),(222,'A múmia visszatér','Érdekes szereplők, egzotikus helyszínek, misztikus közeg, kedves poénok, lendületes cselekmény, egyszóval kedvelem ezt a filmet. '),(223,'A múmia: A Sárkánycsászár sírja','Az egyik kedvenc kalandfilmem.'),(224,'A Spiderwick krónikák','Kellemes, misztikus, családi film :)'),(225,'Apáca show','Eddig ez a film nekem teljesen kimaradt. Most megnéztem és tetszett.'),(226,'Apáca show 2. – Újra virul a fityula','Csodálatos zenével megspékelt, nevetteős film!'),(227,'Átkozott boszorkák','Aranyos, könnyed romantikus vígjáték. Nagyon tetszett. '),(228,'Az élet ízei','Nagyon kedves, kellemes film! '),(229,'Az utolsó vakáció','Én se szeretem a \"nyálas\" filmeket de ez annyira tetszett tegnap már körülbelül ötödszörre láttam fél éven belül.'),(230,'Beépített szépség','Ritkán esem transzba régi filmek kapcsán, de ezen nem látszik a por. Többször is nézhető kedves darab két igazán jó színésszel. '),(231,'Beépített szépség 2: Csábítunk és védünk','Imádom Sandra Bullockot, ez is egy remek filmje, szuper beszólásokkal. '),(232,'Ghost','Azt hiszem ez is az a film, amit látni kell!'),(233,'Hogyan veszítsünk el egy pasit 10 nap alatt','Nagyon aranyos film, jó történettel, szerethetõ karakterekkel és olyan helyszínekkel, amelyek elvarázsoltak'),(234,'Két hét múlva örökké','Nem volt rossz film, kár, hogy a férfi fõszereplõ nagyon nem volt szimpatikus. '),(235,'Legendás állatok és megfigyelésük','3D technika tökéletes megvalósítása'),(236,'Legendás állatok: Grindelwald bűntettei','Ez egy közepes film 5/10 véleményem szerint.'),(237,'Megbocsátasz valaha?','Eszméletlen, élet szűlte sztori!'),(238,'Nász-ajánlat','Az egyik legjobb vígjáték, amit mostanában láttam.'),(239,'Női szervek','Ha ez a film a 90-es években készült volna, ma talán szép emlékű kultuszfilm lenne. Nagyon kemény a B-kategóriás amcsi filmekből jól ismert arrogáns nyomozókarakter női változatban!'),(240,'RED','Nagyon jó kis film.Nem értem a fanyalgókat,a szinkron pedig zseniális. Kikapcsolódásnak tökéletes!'),(241,'RED 2.','Elképesztõen vicces, az akcióvígjátékok sablonossá vált mezején újat mutató, s a végére némi mondanivalót is felmutató, zseniális film!'),(242,'Szeretném, ha szeretnél','Ezredjére is megérte megnézni! :) annyira jó film! '),(243,'Tintaszív','Én nagyon szeretem az akció-vígjátékokat, imádom ha ennek a két mûfajnak a különbözõ hangulatai keverednek, szóval ez is bejött! '),(244,'Zöld Lámpás','Nagyon aranyos film, jó történettel, szerethető karakterekkel és olyan helyszínekkel, amelyek elvarázsoltak');
/*!40000 ALTER TABLE `vélemény` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-11-24 20:36:47
