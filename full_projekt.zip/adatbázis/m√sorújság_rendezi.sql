-- MySQL dump 10.13  Distrib 8.0.18, for Win64 (x86_64)
--
-- Host: localhost    Database: műsorújság
-- ------------------------------------------------------
-- Server version	8.0.18

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `rendezi`
--

DROP TABLE IF EXISTS `rendezi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rendezi` (
  `rendezői_kód` int(11) NOT NULL,
  `rendezett_műsor_címe` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`rendezői_kód`),
  KEY `műsor_címe_idx` (`rendezett_műsor_címe`),
  CONSTRAINT `rendezői_kód` FOREIGN KEY (`rendezői_kód`) REFERENCES `rendező` (`rendezői_kód`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rendezi`
--

LOCK TABLES `rendezi` WRITE;
/*!40000 ALTER TABLE `rendezi` DISABLE KEYS */;
INSERT INTO `rendezi` VALUES (19,'27 idegen igen'),(9,'A bűn királynői'),(15,'A csendestárs'),(11,'A kém'),(26,'A királynő'),(23,'A múmia'),(24,'A múmia visszatér'),(25,'A múmia: A Sárkánycsászár sírja'),(20,'A Spiderwick krónikák'),(17,'Apáca show'),(18,'Apáca show 2. – Újra virul a fityula'),(7,'Átkozott boszorkák'),(21,'Az élet ízei'),(30,'Az utolsó vakáció'),(4,'Beépített szépség'),(5,'Beépített szépség 2: Csábítunk és védünk'),(16,'Ghost'),(6,'Két hét múlva örökké'),(27,'Legendás állatok és megfigyelésük'),(28,'Legendás állatok: Grindelwald bűntettei'),(10,'Megbocsátasz valaha?'),(3,'Nász-ajánlat'),(8,'Női szervek'),(29,'Pokémon – Pikachu, a detektív '),(1,'RED'),(2,'RED 2.'),(13,'Szeretném, ha szeretnél'),(14,'Szeretném, ha szeretnél'),(22,'Tintaszív'),(12,'Zöld Lámpás');
/*!40000 ALTER TABLE `rendezi` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-11-24 20:36:47
