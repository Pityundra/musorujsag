-- MySQL dump 10.13  Distrib 8.0.18, for Win64 (x86_64)
--
-- Host: localhost    Database: műsorújság
-- ------------------------------------------------------
-- Server version	8.0.18

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `színész`
--

DROP TABLE IF EXISTS `színész`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `színész` (
  `színész_kód` int(11) NOT NULL AUTO_INCREMENT,
  `születési_dátum` date DEFAULT NULL,
  `név` varchar(45) DEFAULT NULL,
  `Oscar-díjak_száma` int(11) DEFAULT NULL,
  PRIMARY KEY (`színész_kód`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `színész`
--

LOCK TABLES `színész` WRITE;
/*!40000 ALTER TABLE `színész` DISABLE KEYS */;
INSERT INTO `színész` VALUES (1,'1955-03-19','Bruce Willis',0),(2,'1945-07-26','Helen Mirren',1),(3,'1937-06-01','Morgan Freeman',1),(4,'1964-08-02','Mary-Louise Parker',0),(5,'1953-12-09','John Malkovich ',0),(6,'1937-12-31','Sir Anthony Hopkins',1),(7,'1964-07-26','Sandra Bullock',1),(8,'1976-10-23','Ryan Reynolds',0),(9,'1922-01-27','Betty White',0),(10,'1933-03-14','Sir Michael Caine',2),(11,'1971-01-15','Regina King',0),(12,'1960-09-09','Hugh Grant',0),(13,'1967-06-20','Nicole Kidman',1),(14,'1970-08-26','Melissa McCarthy',0),(15,'1982-06-24','Elisabeth Moss',0),(16,'1979-12-03','Tiffany Haddish',0),(17,'1967-06-26','Jason Statham',0),(18,'1972-12-29','Jude Law',0),(19,'1969-06-24','Jennifer Lopez',0),(20,'1969-11-04','Matthew McConaughey',1),(21,'1975-07-20','Judy Greer',0),(22,'1979-04-19','Kate Hudson',0),(23,'1955-11-13','Whoopi Goldberg',1),(24,'1952-08-18','Patrick Swayze',0),(25,'1962-11-11','Demi Moore',0),(26,'1939-05-13','Harvey Keitle',0),(27,'1934-12-28','Maggie Smith',2),(28,'1978-11-24','Katherine Heigl',0),(29,'1973-09-18','James Marsden',0),(30,'1946-01-26','David Starthairn',0),(31,'1992-02-14','Feddy Highmore',0),(32,'1983-06-17','Manish Dayal',0),(33,'1968-12-03','Brendan Fraser',0),(34,'1970-03-07','Rachel Weisz',1),(35,'1981-03-26','Luke Ford',0),(36,'1982-01-06','Eddie Redmayne',1),(37,'1963-06-09','Johnny Depp',0),(38,'1970-03-18','Queen Latifah',0);
/*!40000 ALTER TABLE `színész` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-11-24 20:36:46
