-- MySQL dump 10.13  Distrib 8.0.18, for Win64 (x86_64)
--
-- Host: localhost    Database: műsorújság
-- ------------------------------------------------------
-- Server version	8.0.18

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `játszik_benne`
--

DROP TABLE IF EXISTS `játszik_benne`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `játszik_benne` (
  `színész_kód` int(11) NOT NULL,
  `műsor_címe` varchar(50) NOT NULL,
  `szerep` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`színész_kód`,`műsor_címe`),
  KEY `címe_idx` (`műsor_címe`),
  CONSTRAINT `műsor_címe` FOREIGN KEY (`műsor_címe`) REFERENCES `műsor` (`címe`),
  CONSTRAINT `színész_kód` FOREIGN KEY (`színész_kód`) REFERENCES `színész` (`színész_kód`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `játszik_benne`
--

LOCK TABLES `játszik_benne` WRITE;
/*!40000 ALTER TABLE `játszik_benne` DISABLE KEYS */;
INSERT INTO `játszik_benne` VALUES (1,'RED','Frank Moses'),(1,'RED 2.','Frank Moses'),(2,'A királynő','II. Erzsébet brit királynő'),(2,'Az élet ízei','Madame Mallory'),(2,'RED','Victoria'),(2,'RED 2.','Victoria'),(2,'Tintaszív','Elinor Loredan'),(3,'RED','Joe Matheson'),(4,'A Spiderwick krónikák','Helen Grace'),(4,'RED','Sarah Ross'),(4,'RED 2.','Sarah Ross'),(5,'RED','Marvin Boggs'),(5,'RED 2.','Marvin Boggs'),(6,'RED 2.','Bailey'),(7,'Átkozott boszorkák','Sally Owens'),(7,'Beépített szépség','Gracie Hart'),(7,'Beépített szépség 2: Csábítunk és védünk','Gracie Hart'),(7,'Két hét múlva örökké','Lucy Kelson'),(7,'Nász-ajánlat','Margaret Tate'),(7,'Női szervek','Sarah Ashburn'),(8,'Nász-ajánlat','Andrew Paxton'),(8,'Pokémon – Pikachu, a detektív ','Pikachu detektív '),(8,'Zöld Lámpás','Hal Jordan'),(9,'Nász-ajánlat','Grandma Annie'),(10,'Beépített szépség','Victor Melling'),(11,'Beépített szépség 2: Csábítunk és védünk','Sam Fuller'),(12,'Két hét múlva örökké','George Wade'),(13,'Átkozott boszorkák','Gillian Owens'),(14,'A bűn királynői','Kathy Brennan'),(14,'A kém','Susan Cooper'),(14,'Megbocsátasz valaha?','Lee Israel'),(14,'Női szervek','Shannon Mullins'),(15,'A bűn királynői','Claire Walsh'),(16,'A bűn királynői','Ruby O\'Carroll'),(17,'A kém','Rick Ford'),(18,'A kém','Bradley Fine'),(18,'Legendás állatok: Grindelwald bűntettei','Albus Dumbledore'),(19,'Szeretném, ha szeretnél','Marina Fiore'),(20,'Hogyan veszítsünk el egy pasit 10 nap alatt','Benjamin Barry'),(20,'Szeretném, ha szeretnél','Dr Steven James'),(21,'27 idegen igen','Casey'),(21,'Szeretném, ha szeretnél','Penny'),(22,'Hogyan veszítsünk el egy pasit 10 nap alatt','Andie Anderson'),(23,'A csendestárs','Laurel Ayres'),(23,'Apáca show','Deloris Van Cartier/Mary Clarence nővér'),(23,'Apáca show 2. – Újra virul a fityula','Deloris Van Cartier/Mary Clarence nővér'),(23,'Ghost','Oda Mae Brown'),(24,'Ghost','Sam Wheat'),(25,'Ghost','Molly Jensen'),(26,'Apáca show','Vince LaRocca'),(27,'Apáca show','Főnökasszony'),(27,'Apáca show 2. – Újra virul a fityula','Tisztelendő anya'),(28,'27 idegen igen','Jane'),(29,'27 idegen igen','Kevin Doyle'),(30,'A Spiderwick krónikák','Arthur Spiderwick'),(31,'A Spiderwick krónikák','Jared Grace/Simon Grace'),(32,'Az élet ízei','Hassan Haji'),(33,'A múmia','Rick O\'Connell'),(33,'A múmia visszatér','Rick O\'Connell'),(33,'A múmia: A Sárkánycsászár sírja','Rick O\'Connell'),(33,'Tintaszív','Mortimer Flochart'),(34,'A múmia','Evelyn Carnahan'),(34,'A múmia visszatér','Evelyn Carnahan'),(34,'A múmia: A Sárkánycsászár sírja','Evelyn Carnahan'),(35,'A múmia: A Sárkánycsászár sírja','Alex O\'Connell'),(36,'Legendás állatok és megfigyelésük','Göthe Salamander'),(36,'Legendás állatok: Grindelwald bűntettei','Göthe Salamander'),(37,'Legendás állatok és megfigyelésük','Geller Grindelwald'),(37,'Legendás állatok: Grindelwald bűntettei','Geller Grindelwald'),(38,'Az utolsó vakáció','Georgia Byrd');
/*!40000 ALTER TABLE `játszik_benne` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-11-24 20:36:46
