-- MySQL dump 10.13  Distrib 8.0.18, for Win64 (x86_64)
--
-- Host: localhost    Database: műsorújság
-- ------------------------------------------------------
-- Server version	8.0.18

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `műsor`
--

DROP TABLE IF EXISTS `műsor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `műsor` (
  `címe` varchar(50) NOT NULL,
  `forgatási_ország` varchar(45) DEFAULT NULL,
  `kiadás_éve` year(4) DEFAULT NULL,
  `korhatár` smallint(20) DEFAULT NULL,
  `stílus` varchar(45) DEFAULT NULL,
  `idő_tartam` int(11) DEFAULT NULL,
  PRIMARY KEY (`címe`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `műsor`
--

LOCK TABLES `műsor` WRITE;
/*!40000 ALTER TABLE `műsor` DISABLE KEYS */;
INSERT INTO `műsor` VALUES ('27 idegen igen','Amerikai Egyesült Államok',2008,12,'Romantikus, Vígjáték',111),('A bűn királynői','Amerikai Egyesült Államok',2019,16,'Krimi, Akció',102),('A csendestárs','Amerikai Egyesült Államok',1996,12,'Vígjáték',114),('A kém','Amerikai Egyesült Államok',2015,16,'Akcióvígjáték',120),('A királynő','Franciaország',2006,12,'Életrajzifilm, Dráma',97),('A múmia','Amerikai Egyesült Államok',1999,12,'Kalandfilm',124),('A múmia visszatér','Amerikai Egyesült Államok',2001,12,'Kalandfilm',130),('A múmia: A Sárkánycsászár sírja','Amerikai Egyesült Államok',2008,12,'Kalandfilm',107),('A Spiderwick krónikák','Kanada',2008,12,'Fantasy',97),('Apáca show','Amerikai Egyesült Államok',1992,12,'Musical, Vígjáték',100),('Apáca show 2. – Újra virul a fityula','Amerikai Egyesült Államok',1993,12,'Musical, Vígjáték',107),('Átkozott boszorkák','Amerikai Egyesült Államok',1998,12,'Romantikus, Misztikus',104),('Az élet ízei','Amerikai Egyesült Államok',2014,12,'Romantikus',118),('Az utolsó vakáció','Amerikai Egyesült Államok',2006,12,'Kaland',107),('Beépített szépség','Amerikai Egyesült Államok',2000,12,'Akció, Komédia',109),('Beépített szépség 2: Csábítunk és védünk','Amerikai Egyesült Államok',2005,12,'Akció, Komédia',115),('Ghost','Amerikai Egyesült Államok',1990,12,'Romantikus',128),('Hogyan veszítsünk el egy pasit 10 nap alatt','Amerikai Egyesült Államok',2003,12,'Romantikus, Vígjáték',116),('Két hét múlva örökké','Amerikai Egyesült Államok',2002,12,'Komédia, Romantikus',101),('Legendás állatok és megfigyelésük','Egyesült Királyság',2016,12,'Kaland, Fantasy',133),('Legendás állatok: Grindelwald bűntettei','Egyesült Királyság',2018,12,'Kaland, Fantasy',134),('Megbocsátasz valaha?','Amerikai Egyesült Államo',2018,16,'Életrajzi Dráma',107),('Nász-ajánlat','Amerikai Egyesült Államok',2009,12,'Komédia, Romantikus',108),('Női szervek','Amerikai Egyesült Államok',2013,16,'Akció, Komédia',117),('Pokémon – Pikachu, a detektív ','Amerikai Egyesült Államok',2019,12,'Fantasy, Misztikus',104),('RED','Amerikai Egyesült Államok',2010,12,'Akció, Komédia',111),('RED 2.','Amerikai Egyesült Államok',2013,12,'Akció, Komédia',116),('Szeretném, ha szeretnél','Amerikai Egyesült Államok',2001,12,'Romantikus, Vígjáték',103),('Tintaszív','Amerikai Egyesült Államok',2009,12,'Fantasy',106),('Zöld Lámpás','Amerikai Egyesült Államok',2011,12,'Akció, Fantasy',114);
/*!40000 ALTER TABLE `műsor` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-11-24 20:36:46
